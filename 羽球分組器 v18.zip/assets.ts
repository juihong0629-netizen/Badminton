export const MALE_AVATAR_URL = "https://i.meee.com.tw/Wc7Np9F.jpg";
export const FEMALE_AVATAR_URL = "https://i.meee.com.tw/APclDIn.jpg";
